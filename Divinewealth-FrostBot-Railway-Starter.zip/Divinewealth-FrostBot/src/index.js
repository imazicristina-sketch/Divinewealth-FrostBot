import mineflayer from 'mineflayer';
import { pathfinder, Movements, goals } from 'mineflayer-pathfinder';
import collectBlockPlugin from 'mineflayer-collectblock';

const cfg = {
  host: process.env.MC_HOST || 'ry9.terohost.in',
  port: Number(process.env.MC_PORT || 25866),
  username: process.env.MC_USERNAME || 'Divinewealth',
  auth: process.env.MC_AUTH || 'offline',
  version: process.env.MC_VERSION || '26.3'
};

let bot;
let reconnectTimer;
let stopping = false;

function log(...args) { console.log(new Date().toISOString(), ...args); }

function start() {
  log(`Connecting ${cfg.username} to ${cfg.host}:${cfg.port} (version ${cfg.version})`);
  bot = mineflayer.createBot({
    host: cfg.host, port: cfg.port, username: cfg.username,
    auth: cfg.auth, version: cfg.version, hideErrors: false
  });
  bot.loadPlugin(pathfinder);
  bot.loadPlugin(collectBlockPlugin);

  bot.once('spawn', () => {
    log('Spawned. Survival automation is starting.');
    const mcData = requireMcData();
    const movements = new Movements(bot, mcData);
    movements.canDig = true;
    movements.allow1by1towers = false;
    movements.allowParkour = true;
    bot.pathfinder.setMovements(movements);
    bot.chat('Hello! I am Divinewealth.');
    beginSurvivalLoop();
  });

  bot.on('chat', (username, message) => {
    if (username === bot.username) return;
    if (message === '!dw stop') { bot.pathfinder.setGoal(null); bot.chat('I will pause my tasks.'); }
    if (message === '!dw follow') {
      const player = bot.players[username]?.entity;
      if (player) bot.pathfinder.setGoal(new goals.GoalFollow(player, 2), true);
    }
    if (message === '!dw status') bot.chat(`Health ${Math.round(bot.health)}; food ${Math.round(bot.food)}; inventory ${bot.inventory.items().length} stacks.`);
  });

  bot.on('kicked', reason => log('Kicked:', reason));
  bot.on('error', err => log('Bot error:', err.message));
  bot.on('end', () => {
    log('Disconnected.');
    if (!stopping) reconnectTimer = setTimeout(start, 15000);
  });
}

function requireMcData() {
  // Loaded lazily so protocol/version errors are visible during startup.
  return (globalThis.__mcData ||= null) || (globalThis.__mcData = getMcData());
}
function getMcData() {
  // minecraft-data is CommonJS-compatible through createRequire in ESM.
  return mcDataLoader(cfg.version);
}
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const mcDataLoader = require('minecraft-data');

let loopBusy = false;
async function beginSurvivalLoop() {
  if (loopBusy) return;
  loopBusy = true;
  while (bot?.entity && bot.health > 0) {
    try {
      // Conservative starter AI: stay safe, eat when hungry, and collect nearby
      // logs when the bot has no wood. More complex base/mining/farming planners
      // are deliberately staged rather than running destructive world edits.
      await eatIfNeeded();
      if (bot.food < 16) await findAndEatFood();
      if (bot.inventory.items().length > 30) log('Inventory is getting full.');
      await sleep(5000);
    } catch (err) {
      log('Survival task:', err.message);
      await sleep(3000);
    }
  }
  loopBusy = false;
}

async function eatIfNeeded() {
  if (bot.food >= 18) return;
  const foods = ['cooked_beef','cooked_porkchop','cooked_mutton','cooked_chicken','bread','baked_potato','cooked_cod','cooked_salmon','apple','carrot','potato'];
  const item = bot.inventory.items().find(i => foods.includes(i.name));
  if (item) { await bot.equip(item, 'hand'); await bot.consume(); log('Ate', item.name); }
}

async function findAndEatFood() {
  // Do not automatically attack players or animals; hunting is opt-in and should
  // be configured for a server where the owner permits it.
  return;
}
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

process.on('SIGTERM', () => { stopping = true; clearTimeout(reconnectTimer); bot?.quit('Railway shutdown'); });
process.on('SIGINT', () => { stopping = true; clearTimeout(reconnectTimer); bot?.quit('Shutdown'); });
start();
